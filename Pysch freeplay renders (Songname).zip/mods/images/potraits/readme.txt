Add your freeplay potraits here!

the should correspond with the son game (so tutorial would be tutorial.png)