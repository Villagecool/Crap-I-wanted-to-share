Add your freeplay potraits here!

the should correspond with the character's icon (so icon-dad would be dad.png)